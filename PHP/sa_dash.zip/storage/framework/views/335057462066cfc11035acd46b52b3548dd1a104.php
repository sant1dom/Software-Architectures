<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('header', null, []); ?> 
		Prediction Consumption
	 <?php $__env->endSlot(); ?>

	 <?php $__env->slot('main_info', null, []); ?> 

		<br><br>
		<a style="font-weight: bold; color: blue; font-size: 1.5rem;"
		   class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
		   href="<?php echo e(route('prediction.production')); ?>">
			Prediction on Production
		</a>
		<br><br>

		<br><br>
		<a style="font-weight: bold; color: blue; font-size: 1.5rem;"
		   class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
		   href="<?php echo e(route('prediction.consumption')); ?>">
			Prediction on Consumption
		</a>
		<br><br>

		<br><br>
		<a style="font-weight: bold; color: blue; font-size: 1.5rem;"
		   class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
		   href="<?php echo e(route('prediction.future')); ?>">
			Prediction on Future bill
		</a>
		<br><br>

	 <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp8\htdocs\sa_dash\resources\views/prediction/prediction_index.blade.php ENDPATH**/ ?>