<td <?php echo e($attributes->merge([
			'class' => 'px-6 py-4 whitespace-nowrap text-sm font-medium dark:text-white',
            'style' => 'border: 1px solid black; text-align: left; text-transform: none; padding: 0.5rem; font-size: 1rem;'
        ])); ?>>
    <?php echo e($slot); ?>

</td><?php /**PATH C:\xampp8\htdocs\sa_dash\resources\views/components/table/td.blade.php ENDPATH**/ ?>