<img <?php echo e($attributes); ?> alt="" src="/img/logo.png">
<?php /**PATH C:\xampp8\htdocs\sa_dash\resources\views/components/dash/logo.blade.php ENDPATH**/ ?>