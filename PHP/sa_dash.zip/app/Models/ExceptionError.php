<?php

namespace App\Models;

use Exception;

class ExceptionError extends Exception
{

}