<?php

namespace App\Models;

use Exception;

class ExceptionUnlogged extends Exception
{

}