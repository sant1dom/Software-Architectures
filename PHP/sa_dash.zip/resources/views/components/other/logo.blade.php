<img {{ $attributes }} alt="" src="/img/logo.png">
