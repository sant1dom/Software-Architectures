<div style="float: left; width: 100%; margin: 3px 3px 30px 3px; border: 1px solid #e5e7eb; border-radius: 6px; padding: 10px; ">
	{{ $slot }}
</div>