<div style="float: left; width: 23%; margin-right: 2%;">
	{{ $slot }}
</div>