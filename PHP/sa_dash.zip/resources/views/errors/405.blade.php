<x-app-layout>
    <x-slot name="title">
        405: Richiesta non valida
    </x-slot>
    <x-slot name="error">
        Errore 405:
        <br><br>
        Richiesta non valida
    </x-slot>
</x-app-layout>
