<x-app-layout>
    <x-slot name="title">
        401: Login necessario
    </x-slot>
    <x-slot name="error">
        Errore 401:
        <br><br>
        Login necessario
    </x-slot>
</x-app-layout>
