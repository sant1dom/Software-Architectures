<x-app-layout>
    <x-slot name="title">
        419: Pagina scaduta
    </x-slot>
    <x-slot name="error">
        Errore 419:
        <br><br>
        Pagina scaduta
    </x-slot>
</x-app-layout>
