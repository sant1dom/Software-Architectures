<x-app-layout>
    <x-slot name="title">
        408: Timeout durante il caricamento della pagina
    </x-slot>
    <x-slot name="error">
        Errore 408:
        <br><br>
        Timeout durante il caricamento della pagina
    </x-slot>
</x-app-layout>
