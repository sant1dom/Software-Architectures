<x-app-layout>
    <x-slot name="title">
        429: Troppe richieste simultanee
    </x-slot>
    <x-slot name="error">
        Errore 429:
        <br><br>
        Troppe richieste simultanee
    </x-slot>
</x-app-layout>
