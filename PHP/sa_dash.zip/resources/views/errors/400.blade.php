<x-app-layout>
    <x-slot name="title">
        404: Richiesta non valida
    </x-slot>
    <x-slot name="error">
        Errore 400:
        <br><br>
        Richiesta non valida
    </x-slot>
</x-app-layout>
