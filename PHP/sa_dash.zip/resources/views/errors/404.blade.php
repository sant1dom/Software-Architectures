<x-app-layout>
    <x-slot name="title">
        404: Pagina non trovata
    </x-slot>
    <x-slot name="error">
        Errore 404:
        <br><br>
        Pagina non esistente o cancellata
        <br><br>
    </x-slot>
</x-app-layout>
